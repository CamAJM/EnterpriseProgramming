package assignmentServ;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import assignmentInitialTest.Film;
import assignmentInitialTest.FilmDAO;

/**
 * Get by name Servlet
 * @author 15083296
 */
@WebServlet("/getByName")
public class getByName extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public getByName() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		FilmDAO dao = new FilmDAO();
		
		// Takes in the "filmname" parameter and calls the getFilmByName function from the dao
		String filmname = request.getParameter("filmname");
		ArrayList<Film> films = dao.getFilmByName(filmname);
		
		// Prints out the movies meeting the parameter.
		for(int i=0;i<films.size(); i++)
		{
			Film a = films.get(i);
			System.out.println(a);
			
		}
		
		

		// MVC Pattern 
		request.setAttribute("films", films);
	    String format = request.getParameter("format");
	    String outputPage;
	    if ("xml".equals(format)) {
	      response.setContentType("text/xml");
	      outputPage = "/WEB-INF/results/films-xml.jsp";
	    } else if ("json".equals(format)) {
	      response.setContentType("application/json");
	      outputPage = "/WEB-INF/results/films-json.jsp";
	    } else if (format == null){
	      response.setContentType("application/json");
	      outputPage = "/WEB-INF/results/films-json.jsp";
	    }else {
		  response.setContentType("text/plain");
		  outputPage = "/WEB-INF/results/films-string.jsp";
		}
	    
	    RequestDispatcher dispatcher =
	      request.getRequestDispatcher(outputPage);
	    dispatcher.include(request, response);
		
		
		
	
	
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
