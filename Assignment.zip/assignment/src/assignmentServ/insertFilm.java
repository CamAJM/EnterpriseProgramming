package assignmentServ;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import assignmentInitialTest.Film;
import assignmentInitialTest.FilmDAO;

/**
 * 
 * Servlet implementation class insertFilm
 * @author 15083296
 * 
 */
@WebServlet("/insertFilm")
public class insertFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public insertFilm() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		// Call the DAO class
		FilmDAO dao = new FilmDAO();
		
		////// Auto generate id //////
		ArrayList<Film> flist = dao.getAllFilms();
		
		int count = flist.size();
		count = count+1;
		
		String id = String.valueOf(count);
		//////////////////////////////	
		
		// Gets the remaining parameters from what is entered.
		String title = request.getParameter("title");
		String year = request.getParameter("year");
		String director = request.getParameter("director");
		String stars = request.getParameter("stars");
		String review = request.getParameter("review");
		
				
		
		// Create a Film object
		Film f1 = new Film(id,title,year,director,stars,review);

				
		ArrayList<Film> films = new ArrayList<Film>();
		
		
		// Adds the new object to the arraylist
		films.add(f1);
		
		// Sends the object to the DAO to be implemented into the database.
		// Permits the ability to add multiple objects at once (unimplemented).
		int j = 0;
		for(int i=0; i<films.size(); i++)
		{
			j++;
			dao.insertFilm(f1);
			
		}
		System.out.println("Added "+j+" entries.");
		


		// MVC Pattern 
		request.setAttribute("films", films);
	    String format = request.getParameter("format");
	    String outputPage;
	    if ("xml".equals(format)) {
	      response.setContentType("text/xml");
	      outputPage = "/WEB-INF/results/films-xml.jsp";
	    } else if ("json".equals(format)) {
	      response.setContentType("application/json");
	      outputPage = "/WEB-INF/results/films-json.jsp";
	    } else if (format == null){
	      response.setContentType("application/json");
	      outputPage = "/WEB-INF/results/films-json.jsp";
	    }else {
		  response.setContentType("text/plain");
		  outputPage = "/WEB-INF/results/films-string.jsp";
		}
	    
	    RequestDispatcher dispatcher =
	      request.getRequestDispatcher(outputPage);
	    dispatcher.include(request, response);

		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
