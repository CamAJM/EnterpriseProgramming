package assignmentServ;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import assignmentInitialTest.Film;

import java.sql.*;


public class FilmDAO {
	
	Film oneFilm = null;
	Connection conn = null;
    Statement stmt = null;

	public FilmDAO() {}

	
	private void openConnection(){
		// MySQL driver
		try{
		    Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch(Exception e) { System.out.println(e); }

		// Connection to mudfoot database
		try{
		    conn = DriverManager.getConnection
	        ("jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:3306/mereditc?user=mereditc&password=hEgsdart6");
		    stmt = conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	   
    }
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	// Gets the next film

	private Film getNextFilm(ResultSet rs){
    	Film thisFilm=null;
		try {
			thisFilm = new Film(
					rs.getString("id"),
					rs.getString("title"),
					rs.getString("year"),
					rs.getString("director"),
					rs.getString("stars"),
					rs.getString("review"));
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	return thisFilm;		
	}
	
	// Gets all films
   public ArrayList<Film> getAllFilms(){
	   
		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    	allFilms.add(oneFilm);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
   }
   
   
   
   
   // Gets the film with the title that is entered

   public ArrayList<Film> getFilmByName(String query){
	   
	   ArrayList<Film> namedFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
			String selectSQL = "select * from films where title like '%"+query+"%';";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
		    if(rs1 == null)
			{
			   System.out.println("Entry already exists.");
			}
			else
			{
			    while(rs1.next())
			    
			    {
			    	oneFilm = getNextFilm(rs1);
			    	namedFilms.add(oneFilm);
			   }

			}
	    // Retrieve the results
		
		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return namedFilms;
   }
   
   // Inserts the given film
   
   public void insertFilm(Film insert)
   {
	   openConnection();
	
	   try{
		   System.out.println(insert);
		   // Checks to see if the film already exists
		   String selectSQL = "select * from films where id like '%"+insert.getId()+"%';";
		   ResultSet rs1 = stmt.executeQuery(selectSQL);
		   if(rs1 == null)
		   {
			   System.out.println("Entry already exists.");
		   }
		   else
		   {
			   // If it doesn't exist, it is then inserted.
			   String insertSQL = "INSERT INTO films VALUES (" + insert + ");";
			   stmt.executeUpdate(insertSQL);
		   }
		   
		   
		   stmt.close();
		   closeConnection();
	   } catch(SQLException se) { System.out.println(se); }
	   
   }
   
   

   
   
   
   
}