package assignmentInitialTest;


import java.util.ArrayList;
import java.util.Scanner;

//import com.google.gson.Gson;

public class Controller {

	static FilmDAO dao = new FilmDAO();
	
	public static void main(String[] args) {
		
		// Sets the scanners to check for inputs.
		Scanner scan = new Scanner(System.in);
		Scanner confirmScan = new Scanner(System.in);
		/*
		 * Convert to Json
		 * 
		 * Gson gson = new Gson();
		 *  
		 * 
		 * String allFilmsJson = gson.toJson(films)
		 * System.out.println(allFilmsJson)
		 * 
		 * 
		 */
		
		
		String query = "";
		
		int confirm;
		
		System.out.println("Do you wish to get all data? 1 for yes, 2 for no");

		confirm = confirmScan.nextInt();

		if (confirm == 2) {
			System.out.println("No");
		} else if (confirm == 1) {
			getAllFilms();
		}
		
		System.out.println("Do you wish to search by name? 1 for yes, 2 for no");
		
		
		confirm = confirmScan.nextInt();

		if (confirm == 2) {
			System.out.println("No");
		}
		else if (confirm == 1) 
		{
			System.out.println("Enter film to be searched for: ");
			
			query = scan.nextLine();
			
			if(query != null)
			{
				getFilm(query);
			}
			else
			{
				System.out.println("No search input has been entered.");
			}
		}
		
		
		
		System.out.println("Would you like to input a film?  1 for yes, 2 for no");
		confirm = confirmScan.nextInt();
		
		if (confirm == 2) {
			System.out.println("No");
		} else if (confirm == 1) {
			insert();
		}
		
		// Closes scanners. Avoids resource leak.
		scan.close();
		confirmScan.close();
		

	}

	private static void insert() 
	{
		// Create a Film object
		Film f1 = new Film("11311", "STAR TREK II: THE WRATH OF KHAN", "1982", "Nicholas Meyer", "William Shatner, Leonard Nimoy, DeForest Kelley", "It was Star Trek II that put the franchise on the right track as the spirit of Gene Roddenberry's 60s television series was harnessed to spectacular effect.");
		
		// Sends the object to the DAO to be implemented into the database.
		dao.insertFilm(f1);
		
		
	}

	private static void getAllFilms() 
	{
		
		ArrayList<Film> flist = dao.getAllFilms();
		
		for (int i = 0; i<flist.size();i++)
		{
			Film b = flist.get(i);
			System.out.println(b);
			
		}
		
		
	}
	
	private static void getFilm(String query)
	{
	
		
		ArrayList<Film> flist = dao.getFilmByName(query);
		
		for (int i = 0; i<flist.size(); i++)
		{
			Film b = flist.get(i);
			System.out.println(b);
		}
		
		
		
	
		
	
	}
	
	
	

}
