package assignmentInitialTest;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
//For jdk1.5 with built in xerces parser
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;


public class XMLCreator {

	//No generic
	List<Film> myData;
	Document dom;

	public XMLCreator() {
		//create a list to hold the data
		myData = new ArrayList<Film>();

		// initialise the list
		loadData();

		//Get a DOM object
		createDocument();
	}


	public void runExample(){
		System.out.println("Started .. ");
		createDOMTree();
		printToFile();
		System.out.println("Generated file successfully.");
	}

	/**
	 * Add a list of books to the list
	 * In a production system you might populate the list from a DB
	 */
	private void loadData(){
		FilmDAO dao = new FilmDAO();
		
		ArrayList<Film> flist = dao.getAllFilms();
		
		for (int i = 0; i<flist.size();i++)
		{
			Film b = flist.get(i);
			myData.add(b);
			
		}
		
		
		
	}

	/**
	 * Using JAXP in implementation independent manner create a document object
	 * using which we create a XML tree in memory
	 */
	private void createDocument() {

		//get an instance of factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try {
		//get an instance of builder
		DocumentBuilder db = dbf.newDocumentBuilder();

		//create an instance of DOM
		dom = db.newDocument();

		}catch(ParserConfigurationException pce) {
			//dump it
			System.out.println("Error while trying to instantiate DocumentBuilder " + pce);
			System.exit(1);
		}

	}

	/**
	 * The real workhorse which creates the XML structure
	 */
	private void createDOMTree(){

		//create the root element <Books>
		Element rootEle = dom.createElement("Films");
		dom.appendChild(rootEle);

		//No enhanced for
		Iterator<Film> it  = myData.iterator();
		while(it.hasNext()) {
			Film b = (Film)it.next();
			//For each Book object  create <Book> element and attach it to root
			Element filmEle = createFilmElement(b);
			rootEle.appendChild(filmEle);
		}

	}

	/**
	 * Helper method which creates a XML element <Book>
	 * @param b The book for which we need to create an xml representation
	 * @return XML element snippet representing a book
	 */
	private Element createFilmElement(Film b){

		Element filmEle = dom.createElement("ID");
		filmEle.setAttribute("ID", b.getId());

		//create author element and author text node and attach it to bookElement
		Element titEle = dom.createElement("Title");
		Text titText = dom.createTextNode(b.getTitle());
		titEle.appendChild(titText);
		filmEle.appendChild(titEle);
		
		Element dirEle = dom.createElement("Director");
		Text dirText = dom.createTextNode(b.getDirector());
		dirEle.appendChild(dirText);
		filmEle.appendChild(dirEle);
		
		//create title element and title text node and attach it to bookElement
		Element yearEle = dom.createElement("Year");
		Node yearText = dom.createTextNode(b.getYear());
		yearEle.appendChild(yearText);
		filmEle.appendChild(yearEle);
		
		Element revEle = dom.createElement("Review");
		Text revText = dom.createTextNode(b.getReview());
		revEle.appendChild(revText);
		filmEle.appendChild(revEle);

		System.out.println(b);
		
		
		return filmEle;

	}

	/**
	 * This method uses Xerces specific classes
	 * prints the XML document to file.
     */
	private void printToFile(){

		try
		{
			//print
			OutputFormat format = new OutputFormat(dom);
			format.setIndenting(true);

			//to generate output to console use this serializer
			//XMLSerializer serializer = new XMLSerializer(System.out, format);


			//to generate a file output use fileoutputstream instead of system.out
			XMLSerializer serializer = new XMLSerializer(
			new FileOutputStream(new File("createdFilm.xml")), format);
			
				
			serializer.serialize(dom);

		} catch(IOException ie) {
		    ie.printStackTrace();
		}
	}


	public static void main(String args[]) {

		//create an instance
		XMLCreator xce = new XMLCreator();

		//run the example
		xce.runExample();
	}
}
