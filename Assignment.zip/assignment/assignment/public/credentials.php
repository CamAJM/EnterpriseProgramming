<?php
// default values for Xampp:
//http://localhost:8012/assignment/socketchat/sign_in.php
$dbhost  = 'localhost';
$dbuser  = 'root';
$dbpass  = '';
$dbname  = 'players';
?>