<?php



// execute the header script:

require_once "header.php";
// Brings in the required files.
require_once "credentials.php";
//includes php to delete users 
include "deleteUser.php";

// Declares the variable
$message = "";
$entered = "";
$show_delete_form = false;
$show_deleteposts_form = false;

echo "hello ";

//getting the admin status and outputting a message to the user 
echo $_SESSION['adminstatus'];

if (!isset($_SESSION['loggedInPlayers']))
{
	// user isn't logged in, display a message saying they must be logged in:
	echo "You must be logged in to view this page.<br>";
}

/*this statment check the status of the user to see if they are an admin and 
then will reveal the content of the page */
elseif ($_SESSION['adminstatus'] == "admin")
{
	
	//only shows the delete form when the admin has been aloud onto the page this means that 
	//other users will not be aloud to delete other users 	
	$show_delete_form = true;
	
	
	$show_deleteposts_form = true;
	
	
	// now read their profile data from the table...
	
	// connect directly to our database (notice 4th argument):
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	
	// check for a row in our profiles table with a matching username: that joins the scores and the colour for each user
	//in the database we use left joins incase members havent set a score or a profile yet
	$query = "SELECT members.*, scores.score, scores.date, profile.colour
				FROM members 
				LEFT JOIN scores
				ON members.username=scores.username
				LEFT JOIN profile
				ON members.username = profile.username ";
	
	// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$n = mysqli_num_rows($result);
	


	
	// if there was a match then extract their profile data:
	if ($result)
	{
		if ($n > 0)
		{
			// out outting the amount users on the system then creating the table 
			echo "<p> there are ' . $n . ' members</p>"; 
			echo '<table>
			<tr><td><strong>Username</stong></td><td><strong>score</td></strong>
			<td><strong>lastest Update</td></strong><td><strong>colour</td></strong></tr>';
			//outputting the date into the table for each member that is in the database
			while($row =  mysqli_fetch_array($result, MYSQLI_ASSOC)){
				echo '<tr><td>' . $row['username'] . '</td><td>' . $row['score'] .'</td><td>' 
			. $row['date'] . '</td><td style="background-color:' .$row['colour'].';"> '.  $row['colour'] . '</td></tr>' ; 
			}
			echo '</table>'; 
			
			mysqli_free_result($result);
		}else{
				//simple error check if there is no data in the database 
			echo '<p class= "error">There are no registered members. </p>';
		
		}
	}
	
	else {
		
		
		// again second error check if the data base had no data in or sql error  
		'<h3 class= "error"> System Error</h3>
		<p class"error">User data could not be retrieved.</p>';
	
	}
	

	// we're finished with the database, close the connection:
	mysqli_close($connection);
		
}
else 
{
	//if the user isnt logged in 
	echo  " You do not have the rights to view this page";
	
}
//if the show delete form then we echo the htlm for the search function and delete button 
//only admin can choose people to delete
if ($show_delete_form)
{
echo <<<_END

<form action="deleteUser.php" method="post">
<br>
  Would you like to delete a user? This cannot be undone:<br><br>
  
  Username: <input type="text" name="search" value="" required> 
  <br>
  <input type="submit" value="Delete">
  
  <br> <br> 
</form>	

_END;
}

//if the show delete form then we echo the htlm for the search function and delete button 
//only admin can choose to delete all posts of a persons profile 

if($show_deleteposts_form)
{
echo <<<_END

<form action="deletepost.php" method="post">
<br>
  Would you like to delete a user? This cannot be undone:<br><br>
  
  Username: <input type="text" name="searchpost" value="" required> 
  <br>
  
  <input type="submit" value="Delete">
  <br> <br> 
</form>	

_END;
}




// Displays the message
echo $message;

// finish off the HTML for this page:
require_once "footer.php";
?>

