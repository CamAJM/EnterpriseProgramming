var express = require("express");
var app = express();
var server = require("http").Server(app);
var io = require("socket.io")(server);

//conects to the sql data base players 
var mysql = require("mysql");
var connection = mysql.createConnection({
host: "localhost",
port: 3306,
user: "root",
password: "",
database: "players"
});



//makes to address public 
app.use(express.static("public"));




//conects to the node server also checks errors 
connection.connect(function(err) {
if (err)
{
console.log(err);
}
else
{
console.log("Connected!");
}
});

var query = connection.query('SELECT * FROM scores');

query
.on('error', function(err) {
// Handle error, an 'end' event will be emitted after this as well
})
.on('fields', function(fields) {
// the field packets for the rows to follow
})
.on('result', function(row) {
// handle each result individually here
console.log(row);
})
.on('end', function() {
// all rows have been received
});

//ends the sql connection with the node  
connection.end(function(err) {
if (err)
{
console.log(err);
}
else
{
console.log("Disconnected!");
}
});
//every time a new player connects then the is a message on the node server 
io.on("connection", function (socket) {
		socket.broadcast.emit("new user connected");
	});
	
io.on("connection", function (socket) {
	console.log("Someone has connected!");

	socket.on("client message", function (data) {
		console.log(data);
		
		io.emit("server message", data);
	});
});

//listening on another server to the node 
server.listen(8081, function(){
	console.log("Server started.")
});

