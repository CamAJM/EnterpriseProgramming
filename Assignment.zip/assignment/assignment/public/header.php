<?php

// Things to notice:
// This script is called by every other script (via include_once)
// It starts the session and displays a different set of menu links depending on whether the user is logged in or not
// It also reads in the credentials for our database connection from credentials.php
//<a href='http://localhost:8081/'>message board</a> ||
// database connection details:
require_once "credentials.php";

// our helper functions:
require_once "helper.php";

// start/restart the session:
session_start();

if (isset($_SESSION['loggedInPlayers']))
{
	// THIS PERSON IS LOGGED IN
	// show the logged in menu options:

echo <<<_END
<!DOCTYPE html>
<html>
<body>
<a href='about.php'>about</a> ||
<a href='finishedgame.php'>play</a> ||
<a href='scores.php'>Learder Board</a> ||
<a href='index.html'>live chat</a> ||
<a href='members.php'>members list</a> ||
<a href='show_profile.php'>show profile</a> ||
<a href='set_profile.php'>set profile</a> ||
<a href='admin_page.php'>Admin Page</a> ||
<a href='delete_account.php'>delete account</a> ||
<a href='messageboard.php'>message board</a> ||
<a href='sign_out.php'>sign out ({$_SESSION['username']})</a>
<br><br>
_END;
}
else
{
	// THIS PERSON IS NOT LOGGED IN
	// show the logged out menu options:
	
echo <<<_END
<!DOCTYPE html>
<html>
<body>
<a href='about.php'>about</a> ||
<a href='sign_up.php'>sign up</a> ||
<a href='sign_in.php'>sign in</a>
<br><br>
_END;
}
?>