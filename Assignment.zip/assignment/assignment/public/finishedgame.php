	<html>
	
<?php
require_once "header.php";

	
	
if (!isset($_SESSION['loggedInPlayers']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{
	$colour = "";
	// user is already logged in, read their username from the session:
	$username = $_SESSION["username"];
	
	// now read their profile data from the table...
	
	// connect directly to our database (notice 4th argument):
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	// check for a row in our profiles table with a matching username:
	$query = "SELECT * FROM profile WHERE username='$username'";
	
	// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$n = mysqli_num_rows($result);
		
	// if there was a match then extract their profile data:
	if ($n > 0)
	{
		// use the identifier to fetch one row as an associative array (elements named after columns):
		$row = mysqli_fetch_assoc($result);
		// display their profile data:
		
		echo "<script>console.log( 'First name: " .$row['username'] . "' );</script>";
		echo "<script>console.log( 'First name: " .$row['colour'] . "' );</script>";
		
		echo "username: {$row['username']}<br>";
		echo "colour: {$row['colour']}<br>";
		
		$colour = $row['colour']; 
		//console.log("First name: {$row['firstname']}<br>");
		//console.log( "Last name: {$row['lastname']}<br>)";
		//console.log( "Age: {$row['age']}<br>");
		//console.log("Email address: {$row['email']}<br>";
		//echo "Date of birth: {$row['dob']}<br>";
	}
	
	
	
	
/*	$currentscore = "";
	$score = $_GET[];

	// check for a row in our profiles table with a matching username:
	$query = "SELECT * FROM scores WHERE username='$username'";
	
	// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$n = mysqli_num_rows($result);
		
	// if there was a match then extract their profile data:
	if ($n > 0)
	{
		$currentscore = $row['score'];
		// use the identifier to fetch one row as an associative array (elements named after columns):
		$row = mysqli_fetch_assoc($result);
	
		echo "<script>console.log( 'High score: " .$row['score'] . "' );</script>";
		echo "High Score: {$row['score']}<br>";
		
		// we need an UPDATE to add the new high score :
			$query = "UPDATE scores SET username ='$username', score= '$score', date= NOW() WHERE username='$username'";
			$result = mysqli_query($connection, $query);
		
		
	} */
	
	else
	{
		// no match found, prompt user to set up their profile:
		echo "You still need to set up a profile!<br>";
	}
	
	// we're finished with the database, close the connection:
	mysqli_close($connection);
		
}
	

?>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	
	<script>
	var myImage = new Image();
	$(document).ready(function() {

			myImage.src = "sprites_final.png";
			myImage.addEventListener("load", draw, false);
	
		    requestAnimationFrame(draw);
			
		    $("body").keydown(function(event) {
		        player.lastKeyPressed = event.which
		        move();
		    });
			
			
			
			
			
			
		/*	function clickbutton() {
			if ($("#uparrow").click(function(event) =true){
				 player.dy = -1;
				 player.dx = 0;
			} 
		}*/
		
		
		
		//upbutton
		$("#uparrow").click(function(event){
			
		 player.dy = -1;
		 player.dx = 0;
		
		
		//requestAnimationFrame(draw)
		
		
			
		//squareHistory.push({
				
		//		x: i,
		//		y: j
		//	});
						
		//	if (squareHistory.length > sl)
		//		{
		//			squareHistory.shift();
		//		}
					
					
		//		console.log(event.which);
			
		});
		
		
		//downbutton
		$("#downarrow").click(function(event){
		console.log("down");
		player.dy = +1;
		player.dx = 0;
		
		//requestAnimationFrame(draw)
		
				
					
				console.log(event.which);
			
		});
		
		//left button 
		$("#leftarrow").click(function(event){
			
		player.dx = -1;
		player.dy = 0;	
		
		//requestAnimationFrame(draw)
					
				console.log(event.which);
			
		});
		
		//rightButton
		$("#rightarrow").click(function(event){
			
		player.dx = +1;
		player.dy = 0;	
		
			//requestAnimationFrame(draw)
									
				console.log(event.which);
			
		});
			
			
			
			
			set_player();
		});
		
		var food = {
			x: Math.round (Math.random() * (15)),
			y: Math.round(Math.random() * (15))
			};
	
	/* // position of start */
		var player = {
		    x: 0,
		    y: 0,
			dx: 1,
			dy:  0,
			lastKeyPressed:0
		    
		};
		
		//var score = 0;
		var radius = 30;
		var player_array;
		
		/* var myImage = new Image();
		myImage.src = "Coin.png";
		myImage.addEventListener("load", loadImage, false);
		
		function loadImage(e) {
 			 animate();
			}
		
		var fps = 5;
		var shift = 80;
		var frameWidth = 99;
		var frameHeight = 99;
		var totalFrames = 3;
		var currentFrame = 0;
		
		unction animate() {
			setTimeout (function(){
		  context.clearRect(120, 25, 300, 300); */
		
		
		/* // creation of the snake */
		
		
		
		
		//checking the high score 
		function setHighScore()
			{
				//sets the score to a string veriable 
				var finalScore = score.toString();
				
				//ajax is used so that we can send the score to the scores page api
				$.ajax({
					type: "POST",
					url: 'api/score.php',
					data: ({Score:finalScore}),
					success: function(data)
					{
						//alert(data);
						
						score= 0;
						
					}
				});
				
			}
		
		
		//setting the player to the first position 
		function set_player() {

		    var length = 2;
		    player_array = [];
	
		    for (var i = length - 1; i >= 0; i--) 
			{ 
			   player_array.unshift({x: i,y: 0});
		    }
		}
		/* // function snake collide with food and random food after collision */
		function eat_food(){
			
			if (player.x == food && player.y ==food1)
				
				{
					score++;
					
					//if (score >=currentscore){
					//	highScore= score;
					//}
					//else 
					//{
					// console.log("score is: " +  score)	;
					//}
					
					console.log("hit");
					var tail =player_array.unshift();
					player_array.unshift(tail);
					
					food = Math.round (Math.random() * (15));
					food1 = Math.round(Math.random() * (15));
				}
		}
		/* //function to detect ir the snake has crashed on its body */
		var checkCollision = function (x, y, player_array){
			for(var i = 0; i<player_array.length; i++){
				if(player_array[i].x == x && player_array[i].y == y)
				return true;
			}
			return false;
		
		}
		
		//when crashed this is called and then restarts the player checks the score 
		function restart(){
			setHighScore();
			set_player();
			
		}
		
		
	
		function move() {
		   /*  // left keypress  */
		    if (player.lastKeyPressed == 37 && player.dx != 1) {
		        console.log("Left");
		        player.dx = -1;
				player.dy = 0;
		    } 
		  /*   // right keypress */ 
		    if (player.lastKeyPressed == 39 && player.dx != -1 ) {
		        console.log("Right");
				player.dx = +1;
				player.dy = 0;
		    } 
		    /* // up keypress  */
		    if(player.lastKeyPressed == 38 && player.dy != 1) {
		        console.log("Up");
		        player.dy = -1;
				player.dx = 0;
		    } 
		    /* // down keypress  */
		    if(player.lastKeyPressed == 40 && player.dy != -1) {
		        console.log("Down");
		        player.dy = +1;
				player.dx = 0;
		    }
			// var dy = snake_array [0];
			// var dx = snake_array [0];
		}	
		    // $("document").mousemove(function(event){ // checks where the cursor movement is on the screen
		    // player.x = event.pageX; // the player will follow the cursor
		    // player.y = event.pageY;
		    // });
		
		
		// speed of the player movement (frames per second)
		var fps = 6;
		// the amount of rows and column cells in the canvas
		var cells = 20;

		
		//food
		//x
		var food = 0;
		//y
		var food1= 0;
		food = getRandomInt(1, cells-1);
		food1 = getRandomInt(1, cells-1);
		var min = 0;
		var max = 0;
		var colour = "<?php echo $colour?>"; 
	

	//var currentscore = "<php echo $currentscore?>"; 
		//var highScore;
		
		//animation
			var sx = 0;
			var swidth = 300;
			var sheight =300;
			var currentframe = 0;
			var maxframe = 24;
			
		function getRandomInt(min, max) {
					
				return Math.floor(Math.random() * (max - min + 1) + min);
					
				}
		
		var score;
		score = 0 ;
		
		/* // function to draw the player and food 	*/
	
	function draw() {
		 
		 setTimeout(function() {

		 var cvs = $("canvas").get(0);

		 var ctx = cvs.getContext("2d");

		
						
			//draw snake
			//ctx.fillStyle="#00FFFF";
			ctx.clearRect(0, 0, cvs.width, cvs.height);
			ctx.fillRect(player.x * cvs.width / cells,
			player.y * cvs.height / cells, 
			cvs.width / cells, 
			cvs.height / cells);	
				
						
						//draw food
						//ctx.fillRect(food.x * cvs.width / cells,
						//food.y * cvs.height / cells, 
						//cvs.width / cells, 
						//cvs.height / cells);
						//var foodPartSizeWidth =food.x * cvs.width/cells;
						//var foodPartSizeHeight =food.y * cvs.height/cells;
						//ctx.clearRect(0, 0, cvs.width, cvs.height);
					
				//drawfood
				
				var snakePartSizeWidth = cvs.width/cells;
				var snakePartSizeHeight = cvs.height/cells;
				ctx.clearRect(0, 0, cvs.width, cvs.height);
						
				var score_output = "Score: " + score;
				ctx.fillStyle = "red";
				ctx.font = "30 Stencil";
				ctx.fillText(score_output,10,10);		
				
				
					
				

		        for (var i = 0; i < player_array.length; i++) {
		            var ab = player_array[i];
					
					//ctx.fillStyle = "black";
					//ctx.strokeStyle = "white";
					//ctx.fillStyle="#00FF40";
					//we call the players favourite colour here
					ctx.fillStyle= colour;
				    ctx.strokeRect(player_array[i].x * cvs.width / cells, 
					player_array[i].y * cvs.height / cells,
					cvs.width / cells,
					cvs.height / cells);
					ctx.fillRect(player_array[i].x * cvs.width / cells, 
					player_array[i].y * cvs.height / cells,
					cvs.width / cells,
					cvs.height / cells);
				}
		            
					
				//sitions the food and actually creates it on the canvus 	
				ctx.drawImage(myImage,sx,0,swidth,sheight,
				food*cvs.width/cells,food1*cvs.height/cells,snakePartSizeWidth,snakePartSizeHeight);
				 
				//creating the sizes for the snake and food so they are in proportion 
				var snakePartSizeWidth = cvs.width/cells;
				
				var snakePartSizeHeight = cvs.height/cells;
				
				//tail 
				sx +=swidth;
				
				
				if (currentframe == maxframe){
				sx = 0;
				currentframe = 0;
				}
				
				currentframe++;
					
					
					requestAnimationFrame(draw);
		            
					
					
				//colision not working properly 	
				player.x += player.dx;
				player.y += player.dy;
				
				player_array.push({
				x: player.x,
				y: player.y
			
				});
				
				eat_food();
				
				var x = player_array.shift();
				
		            /* //  this function makes the snake not colliding with canvas  
		            //  and makes it start from the top left corner after colliding */
		            if (player.x > 19) {
						player.x = 0;
		                player.y = 0;
						player.dx = +1;
						player.dy = 0;
						restart();
		            }
		            if (player.x < 0) {
						player.x = 0;
		                player.y = 0;
						player.dx = +1;
						player.dy = 0;
						restart();
		            }
		            if (player.y > 19) {
						player.y = 0;
		                player.x = 0;
						player.dx = +1;
						player.dy = 0;
						restart();
		            }
		            if (player.y < 0) {
						player.y = 0;
		                player.x = 0;
						player.dx = +1;
						player.dy = 0;
						restart();
		            }
		        
		    }, 1000 / fps);
		}
		//the html for the page so that we can have arrors 
</script>

	</head>
	
	<body>
	
	<canvas width="600" height="600" style="border: solid black 1px">
		Sorry, no canvas support!
	</canvas>
	
	<br>
	<img src="up.png" id = "uparrow" alt="up arrow" style="width:50px;height:50px;">
	<br>
	<img src="left.png" id = "leftarrow" alt="up arrow" style="width:50px;height:50px;">
	<img src="down.png" id = "downarrow" alt="up arrow" style="width:50px;height:50px;">
	<img src="right.png" id = "rightarrow" alt="up arrow" style="width:50px;height:50px;">
	
	</body>

</html>