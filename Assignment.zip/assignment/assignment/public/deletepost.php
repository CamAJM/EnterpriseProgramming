<?php 
//gets php from admin page 
require_once "admin_page.php";

//checks the admin status for the user 
if ($_SESSION['adminstatus'] == "admin")
{
	//requestion the post values from the admin page 
	if ($_SERVER["REQUEST_METHOD"] == "POST") 
	{
		//connecting to the data base
		$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

		// if the connection fails, we need to know, so allow this exit:
		if (!$connection)
		{
			die("Connection failed: " . $mysqli_connect_error);
		}
		//setting connection to a local veriable 
		$conn = $connection;
		//veriable for any error we my occor 
		$errors = array();

		//check to make user a value was entered into the search bar
		if (empty($_POST['searchpost'])) 
		{
			$errors[] = 'You forgot to enter your ID.';
		} 
		//setting the ID = to the serchbar on the admin page 
		else 
		{
			$ID = 
			mysqli_real_escape_string($conn,trim($_POST['searchpost']));
		}
		
		//if the user exists then the sql to delete there posts will be run 
		if (empty($errors)) 
		{ 
			$query1 = "DELETE FROM messageboard WHERE username='$ID'";
			$results1 = @mysqli_query ($conn, $query1);

			//if the sql runs then you have deleted the users posts and a message will output
			if ($results1) 
			{
				echo '<h3>Thank you!</h3>
				<p>You have successfully deleted the users abuse.</p>';	
			} 
			//if there is an error returned then the error message will be outputted 
			else 
			{ 					
				echo '<h3 class="error">System Error</h3>
				<p class="error">Deletion failed because of a system
				error:</p>'; 

				//DEBUGGING echo '<p class="error">' . 
				mysqli_error($conn) . '</p>
				//DEBUGGING <p class="error">Query: ' . $query1 . '</p>';
			} 
			//end the sql
			mysqli_close($conn);
			exit();
		} 
		
		//any pervious errors will be cought here and will be outputted 
		else 
		{ 

			echo '<h3 class="error">Error</h3>

			<p class="error">The following error(s) occurred:</p>';

			foreach ($errors as $message) 
			{ 
				echo "<p class='error'>$message</p>";
			}
			echo '<p>Please try again.</p>';

		} 


	//close the connection if there was an error 
	mysqli_close($conn);

	} 
}
//if not an admin then the page will not load 
else
{
	echo ' You do not have access to this page. ';
}





?>