<?php

// Things to notice:
// The main job of this script is to request the N most recent favourite numbers from the API and display them
// On a successful call to the API (recent.php) the jQuery deletes any old rows in the table and replaces them with the latest data
// The checkForFavourites() function is called again regardless of success/failure
// Right-click and "inspect" in Chrome in order to see the JavaScript debug

// execute the header script:
//require_once "helper.php";
require_once "header.php";


// how many milliseconds to wait between updates:
$milliseconds = 350;

// how many recent favourites to display:
$nrows = 100;
$postchat = "";
$message = "";


if (!isset($_SESSION['loggedInPlayers']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
//change to messageid
elseif (isset($_POST['message']))
{
	// user just tried to update their messege:
	$username = $_SESSION['username'];
	$message = $_POST['message'];
	
	
	
	// connect directly to our database (notice 4th argument) we need the connection for sanitisation:
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// check to see if this user already had a favourite:
	
	$query = "INSERT INTO messageboard (username, message, dateposted) VALUES ('$username','$message', NOW())";
	
		
		// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	
	
}
//POST form(ajax)
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	
<style>
	table, th, td {border: 2px solid black; align: center;}
</style>
<center><table id='post'>
<tr><th>User</th><th>Content</th><th>Posted</th><th>Likes</th><th></th></tr>


</table></center>

<script>


$(document).ready(function()
{	

	$(document).on("click","#post a",function() {
        // user just clicked a "like" link, prevent default behaviour:
		event.preventDefault(); 
		console.log("clicked");
				
		// make a javascript object to hold our request data:
		var request = {};
		request["messageid"] = $(this).data('messageid');
		
		console.log($(this).data('messageid'));

		$.post('api/like.php', request)
		.done(function(data) {
			// debug message to help during development:
			console.log('request successful')
			console.log(data);
			
			// update the relevant user's likes number by one:
			var currentLikes = parseInt($('#' + data.messageid + ' .like').text(),10);
			var newLikes = currentLikes + 1;
			$('#' + data.messageid + ' .like').text(newLikes);
				
		})
		.fail(function(jqXHR) {
			// debug message to help during development:
			console.log('TEST');
			//console.log('request returned failure, HTTP status code ' + jqXHR.status);
		})
		.always(function() {
			// debug message to help during development:
			console.log('request completed');
		});
    
	});
	// as soon as the page is ready, start checking for updates:
	checkForPost();
});

function checkForPost(){
		
    $.getJSON('api/recent.php', {number: $nrows})
		.done(function(data) {
			// debug message to help during development:
			console.log('request successful');
			
			// remove the old table rows:
			$('.result').remove();
			
			// loop through what we got and add it to the table (data is already a JavaScript object thanks to getJSON()):
			$.each(data, function(index, value) {
				$('#post').append("<tr id=messageid class='result'><td>" + value.username + "</td><td>" + value.message + "</td><td>" + value.dateposted + "</td><td class='like'>" + value.likes  + "</td><td>" + "<a data-messageid=" + value.messageid + ">+</a></td></tr>");
			});
		})
		.fail(function(jqXHR) {
			// debug message to help during development:
			console.log('request returned failure, HTTP status code ' + jqXHR.status);
		})
		.always(function() {
			// debug message to help during development:
			console.log('request completed');
			// call this function again after a brief pause:
			setTimeout(checkForPost, $milliseconds);
		});
}
//html for the message board to actually output data onto 
</script>
_END;

echo <<<_END

<center><form id="postchat" action="messageboard.php" method="post">
	<br>
	<b>Messege: <b><input type="text" name="message" maxlength="140" value="$message" required>
		<br><br>
	<input type="submit" id="postchat" value="Submit">
</form></center>
_END;
		
// finish off the HTML for this page:
require_once "footer.php";
?>