<?php

// execute the header script:
require_once "header.php";



echo "A site for people who love retro games.<br>";

// finish of the HTML for this page:
require_once "footer.php";

?>