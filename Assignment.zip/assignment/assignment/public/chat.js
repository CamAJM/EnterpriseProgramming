

$(document).ready(function() {
	//connection to the save port as the node
	var socket = io.connect("http://localhost:8081");
	
	//tputting the message to the html
	$("form").submit(function(e){
		e.preventDefault();
		socket.emit("client message", $("#message").get(0).value);
		$("#message").get(0).value = "";
	});
	//outputting the message on the nbode server 
	socket.on("server message", function(data){
		$("#chatspace").append(data + "<br>");
	});
	
	
	
});