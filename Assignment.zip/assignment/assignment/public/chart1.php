<?php

// Things to notice:
// The main job of this script is to execute a SELECT statement to find the user's profile information

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInPlayers']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{

	echo ' <div id="chart_div"> Chart goes here </div>'
	
	mysqli_close($connection);
		
}

// finish off the HTML for this page:
require_once "footer.php";
?>