<?php

// Things to notice:
// The main job of this script is to execute a SELECT statement to find the user's profile information

// execute the header script:
require_once "/header.php";


if (!isset($_SESSION['loggedInPlayers']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else

{
	
	echo "this is the 10 hight socres of all time! <br>";
	
	// user is already logged in, read their username from the session:
	$username = $_SESSION['username'];
	
	// now read their profile data from the table...
	
	// connect directly to our database (notice 4th argument):
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	// THIS QUARY WILL GIVE US THE TOP TEN SCORES IN DECNDING ORDER
	$query = "SELECT members.* ,scores.score, scores.date, profile.colour
	FROM members
	LEFT JOIN  scores
	ON members.username= scores.username
	LEFT JOIN profile
	ON members.username= profile.username
	ORDER BY score DESC
	LIMIT 10";
	
	
	// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$n = mysqli_num_rows($result);
		
	// if there was a match then extract their profile data:
	if ($result)
	{
		if ($n > 0)
		{
		// use the identifier to fetch one row as an associative array (elements named after columns):
		//$row = mysqli_fetch_assoc($result);
		// display their profile data:
		
		
		
		//echo "<font color =\"{$row['colour']}\">";
		
		echo "<p> there are ' . $n . ' members</p>"; 
			echo '<table>
			<tr><td><strong>Username</stong></td><td><strong>score</td></strong>
			<td><strong>lastest Update</td></strong><td><strong>colour</td></strong></tr>';
		
		
		while($row =  mysqli_fetch_array($result, MYSQLI_ASSOC)){
				echo '<tr><td>' . $row['username'] . '</td><td>' . $row['score'] .'</td><td>' 
			. $row['date'] . '</td><td style="background-color:' .$row['colour'].';"> '.  $row['colour'] . '</td></tr>' ; 
			}
			echo '</table>'; 
		
		
		
		
		
		//echo "<font color ='#000000'>"; 
		
		//echo "user name: {$row['username']}<br>";
		//echo "score: {$row['score']}<br>";
		//echo "updated: {$row['date']}<br>";
		//echo ("colour: <font color=\"{$row['colour']}\"> this is my colour <br>");
		
		 
		mysqli_free_result($result);
		}else{
			
			echo '<p class= "error">There are no registered members. </p>';
		}
	}else {
		'<h3 class= "error"> System Error</h3>
		<p class"error">User data could not be retrieved.</p>';
	
	}
	
	// we're finished with the database, close the connection:
	mysqli_close($connection);
		
}

// finish off the HTML for this page:
require_once "footer.php";
?>