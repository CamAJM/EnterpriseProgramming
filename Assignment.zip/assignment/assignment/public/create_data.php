<?php

// Things to notice:
// NEW: We now create a profile table too
// Testing our PHP scripts work as we expect is very difficult without some data
// This file generates some fake user data that we can use for testing
// You will need something similar to test your 2CWK50 solution
// This file is the first one we will run when we mark your submission

// read in the details of our MySQL server:
require_once "credentials.php";

// We'll use the procedural (rather than object oriented) mysqli calls

// connect to the host:
$connection = mysqli_connect($dbhost, $dbuser, $dbpass);

// exit the script with a useful message if there was an error:
if (!$connection)
{
	die("Connection failed: " . $mysqli_connect_error);
}
  
// build a statement to create a new database:
$sql = "CREATE DATABASE IF NOT EXISTS " . $dbname;

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Database created successfully, or already exists<br>";
} 
else
{
	die("Error creating database: " . mysqli_error($connection));
}

// connect to our database:
mysqli_select_db($connection, $dbname);

///////////////////////////////////////////
////////////// MEMBERS TABLE //////////////
///////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS members";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Dropped existing table: members<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE members (username VARCHAR(16), password VARCHAR(16),adminstatus VARCHAR(16), PRIMARY KEY(username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: members<br>";
}
else 
{
	//end the sql if returned an error 
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames[] = 'barryg'; $passwords[] = 'letmein'; $adminstatus[] = 'admin';
$usernames[] = 'mandyb'; $passwords[] = 'abc123';  $adminstatus[] = 'player';
$usernames[] = 'mathman'; $passwords[] = 'secret95'; $adminstatus[] = 'player';
$usernames[] = 'brianm'; $passwords[] = 'test'; $adminstatus[] = 'player';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO members (username, password, adminstatus ) VALUES ('$usernames[$i]', '$passwords[$i]', '$adminstatus[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

//////////////////////////////////////////////
////////////// SCORES TABLE //////////////
//////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS scores";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
	echo "Dropped existing table: scores<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE scores (username VARCHAR(16), score BIGINT, date TIMESTAMP, PRIMARY KEY(username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: scores<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'barryg'; $score[] = 77; $date[] = '2016-02-15 16:23:12'; 
$usernames[] = 'mandyb'; $score[] = 888; $date[] = '2016-11-05 07:13:52';
$usernames[] = 'mathman'; $score[] = 66; $date[] = '2016-07-23 11:32:21';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO scores (username, score, date) VALUES ('$usernames[$i]', $score[$i], '$date[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}





////////////////////////////////////////////
////////////// profile TABLE //////////////
////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS profile";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
	echo "Dropped existing table: profile<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE profile (username VARCHAR(16), firstname VARCHAR(40), lastname VARCHAR(50), age TINYINT, dob DATE, email VARCHAR(50), colour VARCHAR(8) , PRIMARY KEY (username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: profile<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'barryg'; $firstnames[] = 'Barry'; $lastnames[] = 'Grimes'; $ages[] = 55; $dobs[] = '1961-09-25'; $emails[] = 'baz_g@outlook.com'; $colour[] = '#00FFFF';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO profile (username, firstname, lastname, age, email, dob, colour) VALUES ('$usernames[$i]', '$firstnames[$i]', '$lastnames[$i]', $ages[$i], '$emails[$i]', '$dobs[$i]', '$colour[$i]' )";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

///////////////////////////////////////////
/////////// MESSAGEBOARD TABLE ////////////
///////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS messageboard";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Dropped existing table: messageboard<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE messageboard ( username VARCHAR(16), message VARCHAR(140), messageid SERIAL,dateposted TIMESTAMP,likes INT DEFAULT 0, PRIMARY KEY (messageid))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: messageboard<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'barryg'; $message[] = 'say hello'; $dateposted[] = '2016-02-15 16:23:12';  
$usernames[] = 'mandyb'; $message[] = 'say hello'; $dateposted[] = '2016-02-15 16:23:12';  
$usernames[] = 'mathman'; $message[] = 'say hello'; $dateposted[] = '2016-02-15 16:23:12';  
$usernames[] = 'brianm'; $message[] = 'you cant see me'; $dateposted[] = '2016-02-15 16:23:12';  

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO messageboard (username, message, dateposted ) VALUES ('$usernames[$i]', '$message[$i]', '$dateposted[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}




// we're finished, close the connection:
mysqli_close($connection);
?>