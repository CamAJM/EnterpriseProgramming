<?php

//gets the information for the server 
require_once "../credentials.php";

// set the value of score that we have got from the pervious page to a local veriable 
	$finalScore = $_POST["Score"];
	
session_start();

//global username veriable 
$username = $_SESSION['username'];

//echos the score got from the last page 
echo $finalScore;

//conect to the database
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}	
	
	//this query selects the score from the veriable username = username 
	$query = "SELECT score FROM scores WHERE username='$username'";
	
	//sets the query reult to a veriable 
	$result = mysqli_query($connection, $query);
	
	//if result have a value then checks the high score 
	if($result)
	{
		
		$n = mysqli_num_rows($result);
		
		//if current score already
		if ($n>0)
		{
			
			
			$row = mysqli_fetch_assoc($result);
		//gets the current high score from the database 
			$currentscore = $row['score'];
		//if the high score is less then the new score from the game then update the scores table 
			if ($currentscore< $finalScore)
			{
				//updates the scores table where the username = username 
				$query = "UPDATE scores SET score='$finalScore', date=NOW() WHERE username= '$username'";
				$result = mysqli_query($connection, $query);
				if (!$result)
				{
					echo 'System Error';
				}
			}
		}
		// if there is no score already then there is inserted into the scores table 
		else
		{
		
			$query = "INSERT INTO scores (username,score,date) VALUES ('$username','$finalScore',NOW())";
			$result = mysqli_query($connection, $query);
			//if no result then output error 
			if (!$result)
			{
				echo 'System Error';
			}
		}
	}
	else
	{
		echo'Error in the system';
	}
	
	
	mysqli_close($connection);
	
		
?>	