
	var myImage = new Image();
		$(document).ready(function(){
		
		
			myImage.src = "sprites_final.png";
			myImage.addEventListener("load", draw, false);
			
				
		/*	 this is what you will use to see if you hit the food its a color detector 
			so something like a if not = to then 
			
		$(document).ready(function() {
			
			
			$('td').each(function(index){
			
			$(this).prepend($(this).css("background-color")); */
			
			
			
			
		
		
		
			requestAnimationFrame(draw);
		
		
		//function crash(){
		
		//if (i = cvs.width){
		//	var sl = 5;
		//	var i = 0;
		//	var j = 0;
		//}
		//}
			
		
		
		
			$("body").keydown(function(event){
						
						if (event.which == 38 ){
						
								j=j -1;
								requestAnimationFrame(draw)
							}
						
						if (j == -1){
							j=(cells-1);
						}
							
						if (event.which == 39 ){
								i+= +1;
								requestAnimationFrame(draw)
							}
						if (i == cells){
							i=0;
						}	
							
						if (event.which == 40 ){
						
								j+= +1;
								requestAnimationFrame(draw)
							}
							if (j == cells){
							j=0;
						}	
							
						if (event.which == 37 ){
								i+= -1;
								requestAnimationFrame(draw)
							}
						if (i == -1){
							i=(cells-1);
						}	
							
						squareHistory.push({
							x: i,
							y: j
						});
						
						if (squareHistory.length > sl)
						{
							squareHistory.shift();
						}
					
					
						console.log(event.which);
				});
		});
		
		var fps = 10;
		var cells = 20;
		var sl = 5;
		var i = 0;
		var j = 0;
		
		
		var food = 0;
		var food1= 0;
		food = getRandomInt(1, cells-1);
		food1 = getRandomInt(1, cells-1);
		var min = 0;
		var max = 0;
		
		
		
		//animation
			var sx = 0;
			var swidth = 300;
			var sheight =300;
			var currentframe = 0;
			var maxframe = 24;
			
			
			
		var squareHistory = [];
		
		function getRandomInt(min, max) {
					
					return Math.floor(Math.random() * (max - min + 1) + min);
					
					}
		
		
		
		
		
		
		
		
		function draw() {
		
		
		
		
			setTimeout(function() {

				var cvs = $("canvas").get(0);
				var ctx = cvs.getContext("2d");
			
			
				
				var snakePartSizeWidth = cvs.width/cells;
				var snakePartSizeHeight = cvs.height/cells;
				ctx.clearRect(0, 0, cvs.width, cvs.height);

				//i+= +1;			
				//j=j -1;
				
				ctx.fillRect(i*cvs.width/cells,
							 j*cvs.height/cells,
							 cvs.width/cells,
							 cvs.height/cells);
				
				var snake = []; 			 
							 
				console.log(cvs.height);		

				
				
						for (s = 0; s < squareHistory.length; s++)
						{
						
						
						//ctx.fillStyle="#00FF40";
						ctx.fillRect(squareHistory[s].x*cvs.width/cells,
						squareHistory[s].y*cvs.height/cells,
						snakePartSizeWidth,snakePartSizeHeight);
							
							
							//ctx.drawImage(myImage,sx,0,swidth,sheight,
							//squareHistory[s].x*cvs.width/cells,
							//squareHistory[s].y*cvs.height/cells,
							//snakePartSizeWidth,snakePartSizeHeight);
							
						
							
						}
						
						//ctx.drawImage(myImage,sx,0,swidth,sheight,
						//i*cvs.width/cells,j*cvs.height/cells,snakePartSizeWidth,snakePartSizeHeight);
						
						//ctx.fillStyle("#00FF40");
						ctx.fillStyle="#00FF40";
						ctx.fillRect(i*cvs.width/cells,
						j*cvs.height/cells,
						snakePartSizeWidth,snakePartSizeHeight);
				
				
						ctx.drawImage(myImage,sx,0,swidth,sheight,
						food*cvs.width/cells,food1*cvs.height/cells,snakePartSizeWidth,snakePartSizeHeight);
				 
				
				var snakePartSizeWidth = cvs.width/cells;
				
				var snakePartSizeHeight = cvs.height/cells;
				
				sx +=swidth;
				
				
				if (currentframe == maxframe){
				sx = 0;
				currentframe = 0;
				}
				
				currentframe++;
				
				
				
				requestAnimationFrame(draw);
				
				
				
				
				if (i == food & j == food1){
				 sl = sl + 1;
				food = getRandomInt(1, cells-1);
				food1 = getRandomInt(1, cells-1);
				
				
				
				}
				
				for(cd = 0; cd < squareHistory.length; cd++){
			if (i == squareHistory[cd].x & j == squareHistory[cd].y){
				console.log("end");
				}
				}
				
			}, 1000/fps);
		}
		