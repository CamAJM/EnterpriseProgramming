function getRequestObject(){
	if (window.XMLHttpRequest){
		return(new XMLHttpRequest());
	}else if (window.ActiveXObjext) {
		return(new ActiveXObject("Microsoft.XMLHTTP"));
	}else {
		return (null);
	}
	
}

// Receives the address and sets the output location 
function ajaxResult(address, resultRegion){
	// Turns the request into an object
	var request = getRequestObject();
	
	request.onreadystatechange = function() {showResponseText(request, resultRegion);};
	//used a get request to open the address on the result region 
	request.open("GET",address,true);
	request.send(null);
}
//outputting the response from the server 
 function showResponseText(request,resultRegion) {
	 //when the request is sent and the server has finished returning the response 
	 if((request.readyState== 4) &&
			 (request.status == 200)){
		 htmlInsert(resultRegion, request.responseText);
	 }
	 
 }
 
 
 function searchTitleGET(inputField, resultRegion){
	var baseAddress = "getByName";
	
	var data = "filmname=" + getValue(inputField);
	var address = baseAddress + "?" + data;
	
	
	ajaxResult(address,resultRegion);
	
 }
 
 
 function getValue(id){
	 return(escape(document.getElementById(id).value));
 }
 
function htmlInsert(id,htmlData){
	console.log(document.getElementById(id).innerHTML);
	document.getElementById(id).innerHTML = htmlData;
	
}


///////////////////////////////////////////////////////////////////////////////////////////////


function showFilmPost(inputField, resultRegion){
	
	var address = "getByName";
	var data;
	console.log(inputField);
	
	data = "filmname=" + getValue(inputField);
	//var format =chooseformat();
	
	ajaxResultPost(address,data,resultRegion);
}

//resultRegion
 function ajaxResultPost(address,data,responseHandler){
	 
	 var request= getRequestObject();
	 request.onreadystatechange = function(){
		 showResponseText(request,responseHandler);
	 };
	 
	 request.open("POST", address, true);
	 request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	 request.send(data);
 }
 
 //resultRegion
 function showResponseText(request,responseHandler){
	 if ((request.readyState == 4) && (request.status == 200)){
		 htmlInsert(responseHandler, request.responseText);
	 }
 }
 
 function jsonOutput(inputField, responseHandler){
	 var address = "getByName"
	 var data = "filmname=" + getValue(inputField) + "&format=json";
	 
	 ajaxResultPost(address,data,responseHandler);
 }
 
 function xmlOutput(inputField, responseHandler){
	 var address = "getByName"
	 var data = "filmname=" + getValue(inputField) + "&format=xml";
	 
	 ajaxResultPost(address,data,responseHandler);
 }
 
 function plainOutput(inputField, responseHandler){
	 var address = "getByName"
	 var data = "filmname=" + getValue(inputField) + "&format=string";
	 
	 ajaxResultPost(address,data,responseHandler);
 }
 
 
 ////////////////////////////////////////////////////////////////////////////
 						//XML
 						// Status: Broken
 
 ////////////////////////////////////////////////////////////////////////////
 
 function xmlFilmTable(inputField, responseHandler){
	 var address = "getByName";
	 var data = "filmname=" + getValue(inputField) + "&&format=xml";
	 
	 ajaxResultPost(address,data, function(request){
		 showXmlFilmInfo(request, responseHandler);
	 });
 }
 
function showXmlFilmInfo(request, responseHandler){
	 if((request.readyState == 4) && (request.status == 200)){
		 
		 var xmlDocument = request.responseXML;
		 console.log(xmlDocument);
		 var heading = getXmlValues(xmlDocument,"heading");
		 var films = xmlDocument.getElementsByTagName("Title");
		 var rows = new Array(films.length);
		 var subElementNames = ["title","year", "directors", "stars", "review"];
		 for(var i=0; i<films.length; i++){
			 rows[i]= getElementValues(films[i], subElementTitle);
		 }
		 var table = getTable(heading,rows);
		 htmlInsert(responseHandler,table);
	 }
 }
 
 